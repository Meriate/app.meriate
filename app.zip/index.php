<?php

header('location:account/login.php');
 ?>
